## 1.0.3

- update readme

## 1.0.2

- add discord username to readme

## 1.0.1

- Remove repo URL
- update manifest description
- update readme

## 1.0.0

- initial release
